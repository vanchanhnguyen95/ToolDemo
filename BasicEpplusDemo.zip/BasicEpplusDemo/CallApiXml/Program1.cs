﻿//using System;
//using System.IO;
//using System.Net;
//using System.Net.Http;
//using System.Text;
//using System.Threading.Tasks;
//using System.Xml.Linq;
//using System.Xml.Serialization;

//namespace CallApiXml
//{
//    [XmlRoot(ElementName = "UTLAuthHeader")]
//    public class UTLAuthHeader
//    {

//        [XmlElement(ElementName = "Username")]
//        public string Username { get; set; }

//        [XmlElement(ElementName = "Password")]
//        public string Password { get; set; }

//        [XmlAttribute(AttributeName = "xmlns")]
//        public string Xmlns { get; set; }

//        [XmlText]
//        public string Text { get; set; }
//    }

//    [XmlRoot(ElementName = "Header")]
//    public class Header
//    {

//        [XmlElement(ElementName = "UTLAuthHeader")]
//        public UTLAuthHeader UTLAuthHeader { get; set; }
//    }

//    [XmlRoot(ElementName = "JAddressByGeo")]
//    public class JAddressByGeo
//    {

//        [XmlElement(ElementName = "requestStr")]
//        public string RequestStr { get; set; }

//        [XmlAttribute(AttributeName = "xmlns")]
//        public string Xmlns { get; set; }

//        [XmlText]
//        public string Text { get; set; }
//    }

//    [XmlRoot(ElementName = "Body")]
//    public class Body
//    {

//        [XmlElement(ElementName = "JAddressByGeo")]
//        public JAddressByGeo JAddressByGeo { get; set; }
//    }

//    [XmlRoot(ElementName = "Envelope")]
//    public class Envelope
//    {

//        [XmlElement(ElementName = "Header")]
//        public Header Header { get; set; }

//        [XmlElement(ElementName = "Body")]
//        public Body Body { get; set; }

//        [XmlAttribute(AttributeName = "xsi")]
//        public string Xsi { get; set; }

//        [XmlAttribute(AttributeName = "xsd")]
//        public string Xsd { get; set; }

//        [XmlAttribute(AttributeName = "soap")]
//        public string Soap { get; set; }

//        [XmlText]
//        public string Text { get; set; }
//    }


//    class Program
//    {
//        static async Task Main(string[] args)
//        {
//            Console.WriteLine("Hello World!");
//            // Create the SOAP request object with input parameters
//            var authHeader = new UTLAuthHeader
//            {
//                Username = "bagps",
//                Password = "map.geocode@ba",
//                Xmlns = "http://tempuri.org/"
//            };

//            var jAddressByGeo = new JAddressByGeo
//            {
//                RequestStr = "{\"geo\":[{\"lat\":10.423202,\"lng\":106.175835}],\"typ\":3,\"lan\":\"vn\"}",
//                Xmlns = "http://tempuri.org/"
//            };

//            var header = new Header
//            {
//                UTLAuthHeader = authHeader
//            };

//            var body = new Body
//            {
//                JAddressByGeo = jAddressByGeo
//            };

//            var envelope = new Envelope
//            {
//                Header = header,
//                Body = body,
//                Xsi = "http://www.w3.org/2001/XMLSchema-instance",
//                Xsd = "http://www.w3.org/2001/XMLSchema",
//                Soap = "http://schemas.xmlsoap.org/soap/envelope/",
//                Text = ""
//            };

//            // Serialize the SOAP request object to XML
//            var serializer = new XmlSerializer(typeof(Envelope));
//            var stringWriter = new StringWriter();
//            serializer.Serialize(stringWriter, envelope);

//            // Call the SOAP API with the XML request
//            var apiUrl = "http://geocode.v1.basrv.vn/geocoding.asmx";
//            var request = (HttpWebRequest)WebRequest.Create(apiUrl);
//            request.Method = "POST";
//            request.ContentType = "text/xml;charset=UTF-8";
//            request.Accept = "text/xml";
//            request.Headers.Add("SOAPAction", "\"http://tempuri.org/JAddressByGeo\"");
//            var bytes = Encoding.UTF8.GetBytes(stringWriter.ToString());


//            request.ContentLength = bytes.Length;
//            using (var stream = request.GetRequestStream())
//            {
//                stream.Write(bytes, 0, bytes.Length);
//            }

//            // Get the SOAP API response
//            using (var response = (HttpWebResponse)request.GetResponse())
//            {
//                using (var stream = response.GetResponseStream())
//                {
//                    var reader = new StreamReader(stream);
//                    var result = reader.ReadToEnd();
//                    Console.WriteLine(result);
//                }
//            }

//            Console.ReadLine();

//        }
//    }
//}
