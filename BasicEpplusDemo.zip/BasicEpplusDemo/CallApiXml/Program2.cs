﻿//using System;
//using System.IO;
//using System.Net;
//using System.Net.Http;
//using System.Text;
//using System.Threading.Tasks;
//using System.Xml.Linq;
//using System.Xml.Serialization;

//namespace CallApiXml
//{
//    [XmlRoot(ElementName = "UTLAuthHeader")]
//    public class UTLAuthHeader
//    {

//        [XmlElement(ElementName = "Username")]
//        public string Username { get; set; }

//        [XmlElement(ElementName = "Password")]
//        public string Password { get; set; }

//        [XmlAttribute(AttributeName = "xmlns")]
//        public string Xmlns { get; set; }

//        [XmlText]
//        public string Text { get; set; }
//    }

//    [XmlRoot(ElementName = "Header")]
//    public class Header
//    {

//        [XmlElement(ElementName = "UTLAuthHeader")]
//        public UTLAuthHeader UTLAuthHeader { get; set; }
//    }

//    [XmlRoot(ElementName = "JAddressByGeo")]
//    public class JAddressByGeo
//    {

//        [XmlElement(ElementName = "requestStr")]
//        public string RequestStr { get; set; }

//        [XmlAttribute(AttributeName = "xmlns")]
//        public string Xmlns { get; set; }

//        [XmlText]
//        public string Text { get; set; }
//    }

//    [XmlRoot(ElementName = "Body")]
//    public class Body
//    {

//        [XmlElement(ElementName = "JAddressByGeo")]
//        public JAddressByGeo JAddressByGeo { get; set; }
//    }

//    [XmlRoot(ElementName = "Envelope")]
//    public class Envelope
//    {

//        [XmlElement(ElementName = "Header")]
//        public Header Header { get; set; }

//        [XmlElement(ElementName = "Body")]
//        public Body Body { get; set; }

//        [XmlAttribute(AttributeName = "xsi")]
//        public string Xsi { get; set; }

//        [XmlAttribute(AttributeName = "xsd")]
//        public string Xsd { get; set; }

//        [XmlAttribute(AttributeName = "soap")]
//        public string Soap { get; set; }

//        [XmlText]
//        public string Text { get; set; }
//    }


//    class Program
//    {
//        static async Task Main(string[] args)
//        {
//            // Create the SOAP request object
//            var request = new Envelope()
//            {
//                Xsi = "http://www.w3.org/2001/XMLSchema-instance",
//                Xsd = "http://www.w3.org/2001/XMLSchema",
//                Soap = "http://schemas.xmlsoap.org/soap/envelope/",
//                Header = new Header()
//                {
//                    UTLAuthHeader = new UTLAuthHeader()
//                    {
//                        Username = "bagps",
//                        Password = "map.geocode@ba",
//                        Xmlns = "http://tempuri.org/"
//                    }
//                },
//                Body = new Body()
//                {
//                    JAddressByGeo = new JAddressByGeo()
//                    {
//                        Xmlns = "http://tempuri.org/",
//                        RequestStr = "{\"geo\":[{\"lat\":10.423202,\"lng\":106.175835}],\"typ\":3,\"lan\":\"vn\"}"
//                    }
//                }
//            };

//            // Serialize the SOAP request object to XML
//            var serializer = new XmlSerializer(typeof(Envelope));
//            var stream = new MemoryStream();
//            serializer.Serialize(stream, request);
//            var soapXml = Encoding.UTF8.GetString(stream.ToArray());

//            // Create the HTTP request
//            var url = @"http://geocode.v1.basrv.vn/geocoding.asmx";
//            var httpWebRequest = (HttpWebRequest)WebRequest.Create(url);
//            httpWebRequest.ContentType = "text/xml;charset=UTF-8";
//            httpWebRequest.Accept = "text/xml";
//            httpWebRequest.Method = "POST";

//            string xml = soapXml.ToString();

//            // Write the SOAP request XML to the HTTP request body
//            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
//            {
//                streamWriter.Write(soapXml);
//                streamWriter.Flush();
//                //xml = streamWriter.ToString();
//                streamWriter.Close();
               
//            }

//            // Send the HTTP request and get the response
//            using (var response = (HttpWebResponse)httpWebRequest.GetResponse())
//            {
//                var responseStream = response.GetResponseStream();
//                if (responseStream != null)
//                {
//                    using (var reader = new StreamReader(responseStream))
//                    {
//                        var responseXml = reader.ReadToEnd();
//                        // Handle the SOAP response XML as needed
//                    }
//                }
//            }
//        }
//    }
//}
