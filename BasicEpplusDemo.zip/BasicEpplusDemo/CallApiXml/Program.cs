﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Threading.Tasks;
using System.Xml;

namespace CallApiXml
{
    public class DataJAddressByGeoResult
    {
        public bool accurate { get; set; }
        public int building { get; set; }
        public string commune { get; set; }
        public string district { get; set; }
        public double lat { get; set; }
        public double lng { get; set; }
        public int maxspeed { get; set; }
        public int minspeed { get; set; }
        public string province { get; set; }
        public string road { get; set; }
    }

    public class JAddressByGeoResult
    {
        public List<DataJAddressByGeoResult> data { get; set; }
    }

    class Program
    {
        static async Task Main(string[] args)
        {
            Program obj = new Program();
            Console.WriteLine("Please Enter Input values..");
            decimal lat = 20.941578M;
            decimal lng = 105.966621M;
            obj.InvokeService(lat, lng);
        }

        public void InvokeService(decimal lat, decimal lng)
        {
            HttpWebRequest request = CreateSOAPWebRequest();
            XmlDocument SOAPReqBody = new XmlDocument();
            SOAPReqBody.LoadXml(@"<?xml version=""1.0"" encoding=""utf-8""?>
            <soap:Envelope xmlns:soap=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"">
            <soap:Header>
                <UTLAuthHeader xmlns=""http://tempuri.org/"">
                    <Username>bagps</Username>
                    <Password>map.geocode@ba</Password>
                </UTLAuthHeader>
            </soap:Header>
            <soap:Body>
                <JAddressByGeo xmlns=""http://tempuri.org/"">
                    <requestStr>
                    {""geo"":[{""lat"":" + lat + @",""lng"":" + lng + @"}],""typ"":3,""lan"":""vn""}
                    </requestStr>
                </JAddressByGeo>
            </soap:Body>
            </soap:Envelope>");

            using (Stream stream = request.GetRequestStream())
            {
                SOAPReqBody.Save(stream);
            }

            using (WebResponse Serviceres = request.GetResponse())
            {
                using (StreamReader rd = new StreamReader(Serviceres.GetResponseStream()))
                {
                    var ServiceResult = rd.ReadToEnd();
                    Console.WriteLine(ServiceResult);

                    var xmlDocument = new XmlDocument();
                    xmlDocument.LoadXml(ServiceResult);

                    // Extract information from the XML response
                    XmlNodeList nodes = xmlDocument.GetElementsByTagName("JAddressByGeoResult");
                    foreach (XmlNode node in nodes)
                    {
                        Console.WriteLine(node.InnerText);
                        var geoResult = JsonConvert.DeserializeObject<JAddressByGeoResult>(node.InnerText);
                    }

                    Console.ReadLine();
                }
            }
        }

        public HttpWebRequest CreateSOAPWebRequest()
        {
            HttpWebRequest Req = (HttpWebRequest)WebRequest.Create(@"http://geocode.v1.basrv.vn/geocoding.asmx");
            Req.Headers.Add(@"SOAP:Action");
            Req.ContentType = "text/xml;charset=\"utf-8\"";
            Req.Accept = "text/xml";
            Req.Method = "POST";
            return Req;
        }

    }
}
