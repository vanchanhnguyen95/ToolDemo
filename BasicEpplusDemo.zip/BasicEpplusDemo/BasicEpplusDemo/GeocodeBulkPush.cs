﻿using System.Collections.Generic;

namespace BasicEpplusDemo
{
    //public class GeocodeBulkPush
    //{
    //    public decimal lng { get; set; }
    //    public decimal lat { get; set; }
    //    public string vehicle_code { get; set; }
    //}

    public class Location
    {
        public decimal lng { get; set; }
        public decimal lat { get; set; }
        public string vehicle_code { get; set; }
    }

    public class GeocodeBulkPush
    {
        public List<Location> locations { get; set; }
    }

    public class InfoMation
    {
        public int index { get; set; }
        public string road_name { get; set; }
        public int speed_max { get; set; }
        public string commune { get; set; }
        public string district { get; set; }
        public string province { get; set; }
    }

    public class GeocodeBulkResponse
    {
        public string status { get; set; }
        public List<InfoMation> info { get; set; }
    }
}
