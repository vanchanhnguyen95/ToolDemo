﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace UsingSOAPRequest
{
    public class Program
    {
        static void Main(string[] args)
        {
            Program obj = new Program();
            Console.WriteLine("Please Enter Input values..");
            //int a =Convert.ToInt32(Console.ReadLine());
            //int b =Convert.ToInt32(Console.ReadLine());
            //decimal lat = Convert.ToDecimal(Console.ReadLine());
            //decimal lng = Convert.ToInt32(Console.ReadLine());
            decimal lat = 10.423202M;
            decimal lng = 106.175835M;
            obj.InvokeService(lat, lng);
        }
         public void InvokeService(decimal lat, decimal lng)
         {
            HttpWebRequest request = CreateSOAPWebRequest();
            XmlDocument SOAPReqBody = new XmlDocument();
            SOAPReqBody.LoadXml(@"<?xml version=""1.0"" encoding=""utf-8""?>
            <soap:Envelope xmlns:soap=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"">
            <soap:Header>
                <UTLAuthHeader xmlns=""http://tempuri.org/"">
                    <Username>bagps</Username>
                    <Password>map.geocode@ba</Password>
                </UTLAuthHeader>
            </soap:Header>
            <soap:Body>
                <JAddressByGeo xmlns=""http://tempuri.org/"">
                    <requestStr>
                    {""geo"":[{""lat"":"+ lat + @",""lng"":"+ lng + @"}],""typ"":3,""lan"":""vn""}
                    </requestStr>
                </JAddressByGeo>
            </soap:Body>
            </soap:Envelope>");

            using (Stream stream = request.GetRequestStream())
            {
                SOAPReqBody.Save(stream);
            }

            using (WebResponse Serviceres = request.GetResponse())
            {
                using (StreamReader rd = new StreamReader(Serviceres.GetResponseStream()))
                {
                    var ServiceResult = rd.ReadToEnd();
                    Console.WriteLine(ServiceResult);
                    
                    Console.ReadLine();
                }
            }
         }
       
        public HttpWebRequest CreateSOAPWebRequest()
        {
            HttpWebRequest Req = (HttpWebRequest)WebRequest.Create(@"http://geocode.v1.basrv.vn/geocoding.asmx");
            Req.Headers.Add(@"SOAP:Action");
            Req.ContentType = "text/xml;charset=\"utf-8\"";
            Req.Accept = "text/xml";
            Req.Method = "POST";
            return Req;
        }
    }
}
